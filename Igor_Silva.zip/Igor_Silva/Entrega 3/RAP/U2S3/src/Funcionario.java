public class Funcionario {
    //ATRIBUTOS
    public String nome;
    public String cpf;
    public String rg;
    public String depto;
    public double salario;
}
