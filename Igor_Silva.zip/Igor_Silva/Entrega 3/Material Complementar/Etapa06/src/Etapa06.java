public class Etapa06 {
    public static void main(String[] args) {
		ControleRemoto c1 = new ControleRemoto();
		c1.abrirMenu();
		c1.Ligar();
		c1.maisVolume();
		c1.play();
		c1.abrirMenu();
	}
}
