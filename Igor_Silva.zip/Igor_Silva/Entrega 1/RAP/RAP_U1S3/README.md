## 1)
    A assinatura de um método é uma forma de identificá-lo de maneira única, no caso onde vários métodos que tenham o mesmo nome são diferenciados pelo compilador. Ela é composta por:
    Visibilidade: Tipo de permissão ao método
    Retorno: tipo de retorno do método ou void caso não tenha retorno
    Parâmetros: atributos utilizados dentro do processamento do método
    Exceções: informação de algum erro que pode ocorrer na execução do método.

## 2)
    A sobrecarga permite a existência de vários métodos com o mesmo nome. Métodos sobrecarregados são escritos com o mesmo nome, mas com uma lista de argumentos difernte. São geralmente usados dentro de uma mesma classe.

## 3)
    Um dos critérios que o compilador utiliza para escolher a execução de um método são as suas listas de argumento diferentes.

## 4)
    Não é possível distinguir um método de outro apenas pelo tipo de retorno. O compilador utiliza somente o nome do método e a lista de argumentos para saber se um método é diferente do outro ou não.

## 5)
    A função da palavra reservada this é referenciar o objeto atual

## 6)
#### a)
        