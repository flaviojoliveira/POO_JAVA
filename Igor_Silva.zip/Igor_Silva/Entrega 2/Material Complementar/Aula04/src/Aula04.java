public class Aula04 {
    public static void main (String[] args) {
        Caneta c1 = new Caneta("BIC", "Preta", 0.4f);
        c1.status();

        Caneta c2 = new Caneta("KKK", "Verde", 1.0f);
        c2.status();
    }
}
