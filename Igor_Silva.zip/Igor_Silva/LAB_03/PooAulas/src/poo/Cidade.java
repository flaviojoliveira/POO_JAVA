package poo;

public class Cidade {
	String UF;
	String regiao;
	int habitantes;
	
	public Cidade(String regiao, String UF) {
		this.regiao = regiao;
		this.UF = UF;
	}
}